from django.db import models
from ckeditor.fields import RichTextField
from django.utils.translation import gettext_lazy as _



# CModel for AUTHOR:
class Author(models.Model):

    name            = models.CharField(_("Author's Name"), max_length=50)
    bio             = models.TextField(_("Author's Bio"))
    profile_picture = models.ImageField(_("Author's Profile Picture"),null=True, blank=True, upload_to='profile/')


    def __str__(self):
        return self.name

# Model for CATEGORY:
class Category(models.Model):
    name = models.CharField(_("Blog Post Category"), max_length=50)

    def __str__(self):
        return self.name


# Model for Blog POST:
class BlogPost(models.Model):

    author                  = models.ForeignKey(Author, on_delete=models.CASCADE)

    heading_line            = models.CharField(_("Post's Heading Line"), max_length=255)
    thumbnail_heading_poster= models.ImageField(_("Post's Thumbnail Headline (788x443)"),upload_to='upload/post' ,null=True, blank=True,  max_length=None)
    thumbnail_small_poster  = models.ImageField(_("Post's Thumbnail Small (600x500)"), upload_to='upload/post', max_length=None)
    main_paragraph          = RichTextField(_("Post's Main Paragraph"), null=True, blank=True)
    post_image1             = models.ImageField(_("Post's Image 1 (800x460)"), upload_to='upload/post',  max_length=None)
    post_body               = RichTextField(_("Post's Body"), null=True, blank=True)
    post_image2             = models.ImageField(_("Post's Image 2 (800x460)"), upload_to='upload/post', max_length=None)
    ending_paragraph        = RichTextField(_("Post's Ending Paragraph"), null=True, blank=True)

    category                = models.ForeignKey(Category, on_delete=models.CASCADE, default=None)
    date_created            = models.DateField(_("Post Created on"), auto_now_add=True)
    slug                    = models.SlugField(_("Slug for the POST"), max_length=20, default='', unique=True)

    likes                   = models.IntegerField(_("Number of Likes on Post"))


    class Meta:
        ordering = ['-id']


    def __str__(self):
        return self.heading_line



