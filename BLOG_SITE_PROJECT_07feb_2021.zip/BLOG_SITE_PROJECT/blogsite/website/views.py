from django.shortcuts import render
from .models import Category, Author, BlogPost
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage 


def NavBarContent():
    navContent = {}
    # Fetch all CAEGORISE 
    navCategories = Category.objects.all()
    navContent['NavCategories'] = navCategories

 
    # Fetch 4,4 POSTS from each category.
    navCategoriesPosts = []
    for category in navCategories:
        navCategoriesPosts.extend(list(BlogPost.objects.filter(category=category).order_by('-id')[:4]))
    navContent['NavCategoriesPosts'] = navCategoriesPosts

    return navContent

# Create your views here.

def Home(request):
    content = NavBarContent()
    headline_posts = BlogPost.objects.all().order_by('-id')[:4]
    recet_posts     = BlogPost.objects.all().order_by('-id')

    
    

    # Pagination Code Here
    paginator = Paginator(recet_posts,10)
    page = request.GET.get('page')
    
    try:
        recet_posts = paginator.page(page)
    except PageNotAnInteger:
        recet_posts = paginator.page(1)
    except EmptyPage:
        recet_posts = paginator.page(paginator.num_pages) 
         
    content['recet_posts'] = recet_posts
    content['headline_posts'] = headline_posts

    return render(request, 'home.html', content)
    

def SingleBlog(request, slug):
    content = NavBarContent()

    SinglePost = BlogPost.objects.filter(slug=slug)
    print(SingleBlog)
    content['SinglePost'] = SinglePost
    return render(request, 'single.html', content)
