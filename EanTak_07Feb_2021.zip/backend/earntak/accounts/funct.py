from .models import NewUser, Transections, Referral, Deals
from django.contrib import messages
from django.shortcuts import redirect # HttpResponse, HttpResponseRedirect

def Without_refer_CreateTransactions(request, approve_user):
    # Get Deal Ammount 
    all_deals = Deals.objects.all()
    deal_amount = 0
    for deal in all_deals:
        # Check For Basic Deal
        if deal.deal_name == 'BASIC':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount
        # Check For Standard Deal
        if deal.deal_name == 'STANDARD':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount
        # Check For Advance Deal
        if deal.deal_name == 'ADVANCE':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount

    # Transection For Approve User
    registration_trans = Transections(
        user=approve_user,
        transection_ammount=deal_amount,
        transection_type=True,
        bank_name="Registration Fee",
        tid_check=approve_user.tid_check,
            )
    registration_trans.save()
    try:
        hasnain = NewUser.objects.get(referID="1ADMIN")
        zabi    = NewUser.objects.get(referID="S1ZABI")
        abdul   = NewUser.objects.get(referID="S1ABDUL")

        hasnain_commission  = int((deal_amount/100)*40)
        zabi_commission     = int((deal_amount/100)*40)
        abdul_commission    = int((deal_amount/100)*20)

        # Hasnain Commission Transection
        if hasnain:
            hasnain.wallet +=hasnain_commission
            hasnain.save()
            hasnain_transection = Transections(
                user=hasnain,
                transection_ammount=hasnain_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            hasnain_transection.save()

        # Zabi Commission Transection
        if zabi:
            zabi.wallet +=zabi_commission
            zabi.save()
            zabi_transection = Transections(
                user=zabi,
                transection_ammount=zabi_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            zabi_transection.save()

        # abdul Commission Transection
        if abdul:
            abdul.wallet +=abdul_commission
            abdul.save()
            abdul_transection = Transections(
                user=abdul,
                transection_ammount=abdul_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            abdul_transection.save()

    except NewUser.DoesNotExist:
        messages.error(request, "Something Went Wrong Please Try Again Later.")
        return redirect('approve_user')

def With_refer_CreateTransactions(request, refer_user, approve_user):
    # Get Deal Ammount 
    all_deals = Deals.objects.all()
    deal_amount = 0
    refrance_commission_amount = 0
    for deal in all_deals:
        # Check For Basic Deal
        if deal.deal_name == 'BASIC':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount
        # Check For Standard Deal
        if deal.deal_name == 'STANDARD':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount
        # Check For Advance Deal
        if deal.deal_name == 'ADVANCE':
            if deal.deal_name in approve_user.deal:
                deal_amount = deal.deal_ammount
    # Transection For Approve User
    registration_trans = Transections(
        user=approve_user,
        transection_ammount=deal_amount,
        transection_type=True,
        bank_name="Registration Fee",
        tid_check=approve_user.tid_check,
            )
    registration_trans.save()

    # Calculate Refral Person Commission
    if "Deal (BASIC)" in refer_user.deal:
        refrance_commission_amount = int((deal_amount/100)*40)
    if "Deal (STANDARD)" in refer_user.deal:
        refrance_commission_amount = int((deal_amount/100)*50)
    if "Deal (ADVANCE)" in refer_user.deal:
        refrance_commission_amount = int((deal_amount/100)*60)

    deal_amount -= refrance_commission_amount
    # Transection For Approve User
    refer_user.wallet += refrance_commission_amount
    refer_user.save()
    refral_commission_trans = Transections(
        user=refer_user,
        transection_ammount=refrance_commission_amount,
        transection_type=True,
        bank_name="Registration Commission",
        tid_check=approve_user.tid_check,
            )
    refral_commission_trans.save()
    

   
    try:
        hasnain = NewUser.objects.get(referID="1ADMIN")
        zabi    = NewUser.objects.get(referID="S1ZABI")
        abdul   = NewUser.objects.get(referID="S1ABDUL")

        hasnain_commission  = int((deal_amount/100)*40)
        zabi_commission     = int((deal_amount/100)*40)
        abdul_commission    = int((deal_amount/100)*20)

        # Hasnain Commission Transection
        if hasnain:
            hasnain.wallet +=hasnain_commission
            hasnain.save()
            hasnain_transection = Transections(
                user=hasnain,
                transection_ammount=hasnain_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            hasnain_transection.save()

        # Zabi Commission Transection
        if zabi:
            zabi.wallet +=zabi_commission
            zabi.save()
            zabi_transection = Transections(
                user=zabi,
                transection_ammount=zabi_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            zabi_transection.save()

        # abdul Commission Transection
        if abdul:
            abdul.wallet +=abdul_commission
            abdul.save()
            abdul_transection = Transections(
                user=abdul,
                transection_ammount=abdul_commission,
                transection_type=True,
                bank_name="New Register Commission",
                tid_check=approve_user.tid_check,
                    )
            abdul_transection.save()

    except NewUser.DoesNotExist:
        messages.error(request, "Something Went Wrong Please Try Again Later.")
        return redirect('approve_user')
