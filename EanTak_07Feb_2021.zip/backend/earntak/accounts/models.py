from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
import uuid 



class CustomAccountManager(BaseUserManager):
    
    def create_user(self, email, password, **other_fields):
        if not email:
            raise ValueError(_('You must provide an email address'))
        email   = self.normalize_email(email)
        uid = str(uuid.uuid4())[:6].upper()
        user    = self.model(email=email, referID=uid, **other_fields)

        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **other_fields):
        other_fields.setdefault('user_type', 1)
        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', True)
        other_fields.setdefault('is_active', True)
        other_fields.setdefault('is_active', True)

        if other_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser Must be assigned to is_staff=True'))

        if other_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser Must be assigned to is_superuser=True'))

        return self.create_user(email, password, **other_fields)


    def create_staff(self, email, password, **other_fields):
        other_fields.setdefault('user_type', 2)
        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', False)
        other_fields.setdefault('is_active', True)

        if other_fields.get('is_staff') is not True:
            raise ValueError(_('Staff Must be assigned to is_staff=True'))

        if other_fields.get('is_active') is not True:
            raise ValueError(_('staff Must be assigned to is_active=True'))

        return self.create_user(email, password, **other_fields)

class Deals(models.Model):
    deal_name           = models.CharField(_("Deal name"), max_length=50, blank=True)
    deal_ammount        = models.IntegerField(_("Deal Price"))

    def __str__(self):
        return self.deal_name 


# User Management Models
class NewUser(AbstractBaseUser, PermissionsMixin):
    # Create Unique RefranceID and pick first 6 digites
    
    user_type_data = (
        (1, 'Admin'),
        (2, 'Staff'),
        (3, 'Employee'),
    )

    email           = models.EmailField(_("email address"), unique=True, max_length=254)
    referID         = models.CharField(_("Refrance ID"),    unique=True, max_length=50)
    full_name       = models.CharField(_("User Full Name"), max_length=50, blank=True)
    phone           = models.CharField(_("Phone#"), max_length=50, blank=True)
    created_at      = models.DateField(_("Transections Date"), auto_now_add=True)
    user_type       = models.IntegerField(_("User Type"), default=3, choices=user_type_data)
    wallet          = models.IntegerField(_("Total Ballance of Wallet"), default=0)
    tid_check       = models.CharField(_("Registration TID#"), max_length=50, blank=True)
    deal            = models.CharField(_("Deal Selected"), max_length=50, blank=True)
    payment_method  = models.CharField(_("Payment Method"), max_length=50, blank=True)

    is_staff        = models.BooleanField(default=False)
    is_active       = models.BooleanField(default=False)

    objects = CustomAccountManager()

    USERNAME_FIELD  = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.email  
    

class Referral(models.Model):
    refered_by          = models.ForeignKey(NewUser, on_delete=models.CASCADE)
    new_refrance_id     = models.CharField(_("New Person Refrance ID#"), max_length=50)
    is_active           = models.BooleanField(default=False)

    def __str__(self):
        return self.refered_by.full_name 


class Transections(models.Model):
    transection_type_data = (
        (True, 'debit'),
        (False, 'credit'),
    )
    user                = models.ForeignKey(NewUser, on_delete=models.CASCADE)
    transection_ammount = models.IntegerField(_("Transection Amount"))
    transection_type    = models.BooleanField(_("Transection Type"), choices=transection_type_data)
    transection_date    = models.DateField(_("Transections Date"), auto_now_add=True)
    bank_name           = models.CharField(_("Bank name to which money recieve or sent"), max_length=50)
    tid_check           = models.CharField(_("Transection ID#"), max_length=50,)


    def __str__(self):
        return self.user.email