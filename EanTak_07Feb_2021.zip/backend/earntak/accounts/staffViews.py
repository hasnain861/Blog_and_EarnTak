from django.shortcuts import render
from django.contrib.auth import get_user_model
from django.shortcuts import redirect # HttpResponse, HttpResponseRedirect
from .models import NewUser, Transections, Referral, Deals
from django.contrib import messages
from .funct import With_refer_CreateTransactions, Without_refer_CreateTransactions





# Create your views here.
def StaffHome(request):
    active_users = 0
    non_active_users = 0
    all_users = NewUser.objects.all()
    all_trans = Transections.objects.all().order_by('-id')[:6]
    all_deals = Deals.objects.all()
    recent_users = NewUser.objects.all().order_by('-id')[:6]
    for user in all_users:
        if user.is_active == True:
            active_users += 1
        else:
            non_active_users += 1
    return render(request, 'staff/staff_home.html', {
        'recent_users': recent_users,
        'active_users': active_users,
        'non_active_users':non_active_users,
        'deals':all_deals,
        'trans':all_trans,
        'page':'home'
        })



def ApproveUser(request):
    if request.method =='POST':
        email = request.POST['email']
        try:
            UserModel = get_user_model()
            aprove_user=UserModel.objects.get(email=email)
            if aprove_user:
                # Check The Refral Exist
                try:
                    refer_user = Referral.objects.get(new_refrance_id=aprove_user.referID)
                    if refer_user:
                        With_refer_CreateTransactions(request=request, refer_user=refer_user.refered_by, approve_user=aprove_user)
                        aprove_user.is_active=True
                        aprove_user.save()
                        messages.success(request, f"The Account of {aprove_user.full_name} Successfully Active !")
                        return redirect('approve_user')
                except Referral.DoesNotExist:
                    Without_refer_CreateTransactions(request=request,approve_user=aprove_user)
                    aprove_user.is_active=True
                    aprove_user.save()
                    messages.success(request, f"The Account of {aprove_user.full_name} Successfully Active !")
                    return redirect('approve_user')
        except UserModel.DoesNotExist:
            messages.error(request, "Something Went Wrong Please Try Again Later.")
            return redirect('approve_user')
    else:
        all_users = NewUser.objects.filter(is_active=False)
        all_deals = Deals.objects.filter()
        return render(request, 'staff/approve_user.html', {'users':all_users, 'deals':all_deals, 'page':'approve_user'})





def WidthdrawalPayment(request):
    if request.method =='POST':
        email = request.POST['email']
        tid = request.POST['tid_confirm']
        try:
            UserModel = get_user_model()
            aprove_user=UserModel.objects.get(email=email)
            if aprove_user:
                payment_trans = Transections(
                    user=aprove_user,
                    transection_ammount=aprove_user.wallet,
                    transection_type=False,
                    bank_name="Widthdrawal",
                    tid_check=tid,
                        )
                payment_trans.save()
                msg = f"Rs.{aprove_user.wallet}/- Paid to {aprove_user.full_name} Successfully !"
                aprove_user.wallet=0
                aprove_user.save()
                messages.success(request, msg)
                return redirect('widthdrawal_payment')
        except UserModel.DoesNotExist:
            messages.error(request, "Something Went Wrong Please Try Again Later.")
            return redirect('widthdrawal_payment')
    else:
        all_users = NewUser.objects.filter(is_active=True, wallet__gt=100)
        all_deals = Deals.objects.filter()
        return render(request, 'staff/withdrawal_payment.html', {'users':all_users, 'deals':all_deals, 'page':'widthdrawal_payment'})



def AllEmployees(request):
    all_users = NewUser.objects.filter(is_active=True, user_type=3)
    all_referral = Referral.objects.all()
    all_deals = Deals.objects.filter()
    return render(request, 'staff/all_employee.html', {'page':'employees', 'users':all_users, 'referral': all_referral,'deals':all_deals})

def AllTrans(request):
    all_trans = Transections.objects.all()
    return render(request, 'staff/all_trans.html', {'trans':all_trans, 'page':'trans'})

def MyWallet(request):
    user = request.user
    my_trans = Transections.objects.filter(user=user)
    return render(request, 'staff/my_wallet.html', {'trans':my_trans, 'page':'my_wallet'})