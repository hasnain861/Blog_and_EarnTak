from django.shortcuts import render
from django.shortcuts import redirect, HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import get_user_model
from .models import NewUser, Transections, Referral, Deals
from django.contrib import messages



# Create your views her
def SubmitTid(request):
    if request.method == "POST":
        tid =  request.POST['tid']
        email =  request.POST['email']
        try:
            UserModel = get_user_model()
            user=UserModel.objects.get(email=email)
            if user:
                user.tid_check = tid
                user.save()
                messages.success(request, "Thank You for Submitting Transection TID# Soon Admin Will Approve Your Account and you will Recieve a confirmation Email")
                return redirect('show_login')
        except UserModel.DoesNotExist:
            messages.error(request, "Something Went Wrong Please Try Again Later.")
            return redirect('show_login')

    else:
        messages.error(request, "Something Went Wrong Please Try Again Later.")
        return redirect('show_login')


def Base(request):
    return render(request, 'admin/create_staff.html')
  


def DoLogin(request):
    
    if request.method == "POST":
        email       = request.POST['email']
        password       = request.POST['password']

        try:
            UserModel = get_user_model()
            user=UserModel.objects.get(email=email)
            if user:
                if user.check_password(password):
                    if user.is_active!=True:
                        return render(request, 'website/request_success.html', {"user":user})
                    else:
                        login(request,user)
                        if user.user_type==1:
                            return redirect('admin_home')
                        elif user.user_type==2:
                            return redirect('staff_home')
                        else:
                            return redirect('employee_home')
                else:
                    messages.error(request, "Invalid Password.")
                    return render(request, 'authentication/login.html')
                
        except UserModel.DoesNotExist:
            messages.error(request, "Invalid Email Address.")
            return render(request, 'authentication/login.html')
    else:
        return render(request, 'authentication/login.html')


def RegisterRequest(request):
    deals = Deals.objects.all()
    if request.method =="POST":
        email           = request.POST['email']
        full_name       = request.POST['full_name']
        phone           = request.POST['phone']
        deal_name       = request.POST['deal']
        epassword       = request.POST['epassword']
        cpassword       = request.POST['cpassword']
        payment_method  = request.POST['paymentMethod']
        agree       = False
        if "agree" in request.POST:
            agree = True
        UserModel = get_user_model()

        # Basic Checks For User Registration Request
        if not agree:
            messages.error(request, 'You must have to agree our all Terms and Conditions to create an account here.')
            return render(request, 'website/register.html', {'deals':deals})

        # Check Password is match
        if epassword != cpassword:
            messages.error(request, "Password you entered doesn't match with confirm password.")
            return render(request, 'website/register.html', {'deals':deals})

        # Check if Email is already Taken
        try:
            user=UserModel.objects.get(email=email)
            if user:
                messages.error(request, "This Email is already Register, Please Try with other one !")
                return render(request, 'website/register.html', {'deals':deals})
        except UserModel.DoesNotExist:
            pass

        # Check If Reffral Prson If Exist or not
        if request.POST['reffral_id']:
            reffral_id  = request.POST['reffral_id'].upper()
            try:
                Reffral_user=UserModel.objects.get(referID=reffral_id)
                # Create New User and Refral Table
                if Reffral_user:
                    NewUserCreated=UserModel.objects.create_user(
                        email=email,
                        password=epassword,
                        full_name=full_name,
                        phone=phone,
                        deal=deal_name,
                        payment_method=payment_method
                        )
                    NewUserCreated.save()
                    if Reffral_user and NewUserCreated:
                        referral=Referral(
                        refered_by=Reffral_user, 
                        new_refrance_id=NewUserCreated.referID,
                        )
                        referral.save()
                        return render(request, 'website/request_success.html', {"user":NewUserCreated})
            except UserModel.DoesNotExist:
                messages.error(request, "There is no user with this Refrance ID# that you Entered. Please Try to confirm the correct Refrance ID# from that person who reffer you to register on our site. ")
                return render(request, 'website/register.html', {'deals':deals})
        else:
            NewUserCreated=UserModel.objects.create_user(
                email=email,
                password=epassword,
                full_name=full_name,
                phone=phone,
                deal=deal_name,
                payment_method=payment_method  
                )
            NewUserCreated.save()
            if NewUserCreated:
                return render(request, 'website/request_success.html', {"user":NewUserCreated})
            else:
                messages.error(request, "Something went wrong Please Try again !")
                return render(request, 'website/register.html', {'deals':deals})
    else:
        return render(request, 'website/register.html', {'deals':deals})

def Website(request):
    deals = Deals.objects.all()
    # messages.error(request, "There is no user with this Refrance ID# that you Entered. Please Try to confirm the correct Refrance ID# from that person who reffer you to register.")
    return render(request, 'website/index.html', {'deals':deals})

def Logout(request):
    logout(request)
    messages.success(request, "logout Successfully !")
    return redirect('show_login')