from django.shortcuts import render
from django.contrib.auth import get_user_model
from .models import Transections
from django.shortcuts import redirect, HttpResponse, HttpResponseRedirect


# Create your views here.
def AdminHome(request):
    return render(request, 'admin/admin_home.html')

def TestStaffCreate(request):
    try:
        newTransection=Transections(
            user=request.user, 
            transection_ammount=100, 
            transection_type= False,
            bank_name="JazzCash"
            )
        newTransection.save()
        print('Transections Created !!!!!!!!')
        return redirect("admin_home")
    except Exception as e:
        print(e)
        return render(request, 'authentication/login.html')
