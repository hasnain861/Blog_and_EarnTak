from django.contrib import admin
from .models import NewUser, Transections, Referral, Deals

# Register your models here.

admin.site.register(NewUser)
# admin.site.register(Wallet)
admin.site.register(Transections)
admin.site.register(Referral)
admin.site.register(Deals)