from django.utils.deprecation import MiddlewareMixin
from django.urls import reverse
from django.contrib import messages
from django.http import HttpResponseRedirect

class LoginCheckMiddleWare(MiddlewareMixin):

    def process_view(self,request,view_func,view_args,view_kwargs):
        modulename=view_func.__module__
        user=request.user
        if user.is_authenticated:
            # Restrictions For  User Type -> (ADMIN)
            if user.user_type == 1:
                if modulename == 'accounts.adminViews':
                    pass
                elif modulename == 'accounts.staffViews':
                    pass
                elif modulename == 'accounts.employeeViews':
                    pass
                elif  modulename == 'accounts.views':
                    pass
                elif  modulename == 'django.contrib.admin.urls':
                    pass
                else:
                    messages.error(request, "Invalid url Request.")
                    return HttpResponseRedirect(reverse('admin_home'))
            # Restrictions For  User Type -> (STAFF)
            if user.user_type == 2:
                if modulename == 'accounts.staffViews':
                    pass
                elif  modulename == 'accounts.views':
                    pass
                else:
                    messages.error(request, "Invalid url Request.")
                    return HttpResponseRedirect(reverse('staff_home'))
            # Restrictions For  User Type -> (EMPLOYEE)
            elif user.user_type == 3:
                if modulename == 'accounts.employeeViews':
                    pass
                elif  modulename == 'accounts.views':
                    pass
                else:
                    messages.error(request, "Invalid url Request.")
                    return HttpResponseRedirect(reverse('employee_home'))
            else:
                messages.error(request, "Invalid url Request.")
                return HttpResponseRedirect(reverse('show_login'))
                    
        else:
            if  modulename == 'accounts.views':
                pass
            # if request.path == reverse('show_login')or request.path == reverse('website')  or request.path == reverse('register_request') or request.path == reverse('submitedtid'):
            #     pass
            else:
                messages.error(request, "Invalid url Request.")
                return HttpResponseRedirect(reverse('show_login'))