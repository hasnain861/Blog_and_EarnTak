from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.urls import path
from accounts.views import (
    Base, DoLogin, Website, RegisterRequest, SubmitTid, Logout
)
from accounts.adminViews import (
    AdminHome, TestStaffCreate
)

from accounts.staffViews import (
    StaffHome,
    ApproveUser,
    AllEmployees,
    AllTrans,
    WidthdrawalPayment,
    MyWallet,
)

from accounts.employeeViews import (
    EmployeeHome,
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # Password Reset Links URLS
    path('reset_password/',
        auth_views.PasswordResetView.as_view(template_name='authentication/PRenterEmail.html'),
        name="reset_password"),

    path('reset_password_sent/', 
        auth_views.PasswordResetDoneView.as_view(template_name='authentication/PRemailSent.html'), 
        name="password_reset_done"),

    path('reset/<uidb64>/<token>/',
        auth_views.PasswordResetConfirmView.as_view(template_name='authentication/PRenterNewPassword.html'), 
        name="password_reset_confirm"),

    path('reset_password_complete/', 
        auth_views.PasswordResetCompleteView.as_view(template_name='authentication/PRcomplete.html'), 
        name="password_reset_complete"),


        
    # Website URLS
    path('', Website, name='website'),
    path('register/', RegisterRequest, name="register_request"),
    path('submitedtid/', SubmitTid, name="submitedtid"),
    path('logout', Logout,name="logout"),

    # Login and Register URLS
    # path('login/', Base, name='show_login'),
    path('login/', DoLogin, name='show_login'),


    # Admin URLS 
    path('home/',AdminHome, name='admin_home'),
    path('create/',TestStaffCreate, name='test'),


    #  Staff URLS 
    path('staffhome/',StaffHome, name='staff_home'),
    path('approve/',ApproveUser, name='approve_user'),
    path('allemployees/',AllEmployees, name='all_employees'),
    path('alltrans/',AllTrans, name='all_trans'),
    path('payment/',WidthdrawalPayment , name='widthdrawal_payment'),
    path('mywallet/',MyWallet, name='my_wallet'),


    #  Employee URLS 
    path('employeehome/',EmployeeHome, name='employee_home')
]


